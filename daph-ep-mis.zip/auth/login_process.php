<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/db_connect.php';
require_once '../config/constants.php';
require_once './audit_helper.php';

if (!isset($_SESSION['login_attempts'])) $_SESSION['login_attempts'] = 0;
if ($_SESSION['login_attempts'] >= 5) {
    $_SESSION['login_error'] = "Too many attempts. Wait 15 minutes.";
    header("Location: ../index.php");
    exit();
}

$login_id      = trim($_POST['login_id'] ?? '');
$password      = $_POST['password'] ?? '';
$user_category = trim($_POST['user_category'] ?? '');

$district_id               = isset($_POST['district_id']) ? intval($_POST['district_id']) : null;
$range_id                  = isset($_POST['range_id']) ? intval($_POST['range_id']) : null;
$training_center_id        = isset($_POST['training_center_id']) ? intval($_POST['training_center_id']) : null;
$training_center_location  = trim($_POST['training_center_location'] ?? '');
$farm_id                   = isset($_POST['farm_id']) ? intval($_POST['farm_id']) : null;

// Validate essential inputs
if (empty($login_id) || empty($password) || empty($user_category)) {
    $_SESSION['login_error'] = "Please fill in all identity credentials and parameters.";
    header("Location: ../index.php");
    exit();
}

$category_to_role_map = [
    'provincial_director'            => ['provincial_director'],
    'additional_provincial_director' => ['provincial_director'],
    'subject_matter_specialist'      => ['sms'],
    'deputy_director_hq_1'           => ['deputy_director_hq_1', 'provincial_director'],
    'administrator'                  => ['administrator'],
    'accounts_branch'                => ['finance_admin'],
    'deputy_director_hq_2'           => ['deputy_director_hq_2', 'provincial_director'],
    'deputy_director_district'       => ['district_dd', 'deputy_director_district'],
    'range_veterinary_officer'       => [
        'veterinary_surgeon',
        'government_veterinary_surgeon',
        'additional_veterinary_surgeon',
        'livestock_development_officer',
        'development_officer',
        'driver',
        'dispensary_assistant',
        'department_laborer',
        'night_watcher',
        'employee'
    ],
    'training_centers'               => ['training_officer'],
    'regional_farms'                 => ['farms_dd']
];

$allowed_roles_for_cat = $category_to_role_map[$user_category] ?? [$user_category];

$field = filter_var($login_id, FILTER_VALIDATE_EMAIL) ? 'email' : 'username';

$stmt = $mysqli->prepare("
    SELECT id, username, email, password, full_name, role, range_id, district_id, district, farm_id 
    FROM users 
    WHERE $field = ? AND is_active = 1 
    LIMIT 1
");

if (!$stmt) {
    die("SQL Structural Error: " . $mysqli->error);
}

$stmt->bind_param("s", $login_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['login_attempts']++;
    $_SESSION['login_error'] = "Invalid verification credentials.";
    header("Location: ../index.php");
    exit();
}

$user = $result->fetch_assoc();

if (!in_array($user['role'], $allowed_roles_for_cat)) {
    $_SESSION['login_attempts']++;
    $_SESSION['login_error'] = "Authorization Role mismatch for this account footprint.";
    header("Location: ../index.php");
    exit();
}

// Infer district_id from district text if missing
if (empty($user['district_id']) && !empty($user['district'])) {
    if (strcasecmp($user['district'], 'Amparai') === 0 || strcasecmp($user['district'], 'Ampara') === 0) {
        $user['district_id'] = 1;
    } elseif (strcasecmp($user['district'], 'Batticaloa') === 0) {
        $user['district_id'] = 2;
    } elseif (strcasecmp($user['district'], 'Trincomalee') === 0) {
        $user['district_id'] = 3;
    }
}

// Infer district text from district_id if missing
if (!empty($user['district_id']) && empty($user['district'])) {
    $d_stmt = $mysqli->prepare("SELECT name FROM districts WHERE id = ? LIMIT 1");
    if ($d_stmt) {
        $d_stmt->bind_param("i", $user['district_id']);
        $d_stmt->execute();
        $d_res = $d_stmt->get_result();
        if ($d_row = $d_res->fetch_assoc()) {
            $user['district'] = $d_row['name'];
        }
        $d_stmt->close();
    }
}

// Fallback: If user has no district_id in DB, but selected one during login
if (empty($user['district_id']) && $district_id) {
    $user['district_id'] = $district_id;
}

// Validate matching districts for specialized district fields
if (in_array($user_category, ['deputy_director_district', 'range_veterinary_officer'])) {
    if ($user['district_id'] !== null && intval($user['district_id']) !== $district_id) {
        $_SESSION['login_error'] = "Access denied: Account assigned to a different district region.";
        header("Location: ../index.php");
        exit();
    }
}

// Validate matching range layout metrics for Range Officers
if ($user_category === 'range_veterinary_officer') {
    if ($user['range_id'] !== null && intval($user['range_id']) !== $range_id) {
        $_SESSION['login_error'] = "Access denied: Account structural Range assignment error.";
        header("Location: ../index.php");
        exit();
    }
}

if ($user_category === 'training_centers') {
    if (empty($training_center_id) || empty($training_center_location)) {
        $_SESSION['login_error'] = "Please select both the training center and its location.";
        header("Location: ../index.php");
        exit();
    }

    $training_center_stmt = $mysqli->prepare("SELECT id, location FROM training_centers WHERE id = ? AND is_active = 1 LIMIT 1");
    if (!$training_center_stmt) {
        $_SESSION['login_error'] = "Unable to validate training center assignment.";
        header("Location: ../index.php");
        exit();
    }

    $training_center_stmt->bind_param("i", $training_center_id);
    $training_center_stmt->execute();
    $training_center_result = $training_center_stmt->get_result();

    if ($training_center_result->num_rows === 0) {
        $_SESSION['login_error'] = "Access denied: Invalid training center selection.";
        header("Location: ../index.php");
        exit();
    }

    $training_center = $training_center_result->fetch_assoc();
    if (strcasecmp(trim($training_center['location'] ?? ''), trim($training_center_location)) !== 0) {
        $_SESSION['login_error'] = "Access denied: Training center location does not match the selected center.";
        header("Location: ../index.php");
        exit();
    }
}


if (password_verify($password, $user['password'])) {

    $_SESSION['user_id']                  = $user['id'];
    $_SESSION['username']                 = $user['username'];
    $_SESSION['full_name']                = $user['full_name'];
    $_SESSION['role']                     = $user['role'];
    $_SESSION['range_id']                 = $user['range_id'];
    $_SESSION['district_id']              = $user['district_id'];
    $_SESSION['district']                 = $user['district'] ?? 'Provincial';
    $_SESSION['user_category']            = $user_category;
    $_SESSION['training_center_location'] = $training_center_location;

    // For HQ, Administrator, and Accounts Branch roles, ensure global/province-wide scope
    if (in_array($user['role'], ['deputy_director_hq_1', 'deputy_director_hq_2', 'provincial_director', 'administrator', 'finance_admin'])) {
        $_SESSION['district_id'] = null;
        $_SESSION['district']    = 'Provincial';
    }

    if ($training_center_id) $_SESSION['training_center_id'] = $training_center_id;

    // Use farm_id from database if available; fallback to posted farm_id dropdown selection
    if (!is_null($user['farm_id'])) {
        $_SESSION['farm_id'] = intval($user['farm_id']);
    } elseif ($farm_id) {
        $_SESSION['farm_id'] = $farm_id;
    }

    $_SESSION['logged_in']     = true;

    // Update login timestamp counter
    $mysqli->query("UPDATE users SET last_login = NOW() WHERE id = " . (int)$user['id']);

    // Log tracking operational footprint
    logActivity($mysqli, $user['id'], 'LOGIN', 'users', $user['id'], null, null, "User logged in with context: " . $user_category);

    unset($_SESSION['login_attempts']);
    unset($_SESSION['login_error']);

    header("Location: ../dashboard.php");
    exit();
} else {
    $_SESSION['login_attempts']++;
    $_SESSION['login_error'] = "Invalid verification credentials.";
    header("Location: ../index.php");
    exit();
}
