<?php
session_start();
require_once __DIR__ . '/../../../config/db_connect.php';

/** @var mysqli $mysqli */
global $mysqli;


$allowed_roles = [
    'veterinary_surgeon',
    'sms',
    'district_dd',
    'deputy_director_district',
    'administrator',
    'provincial_director',
    'deputy_director_hq_1',
    'deputy_director_hq_2',
    'admin'
];

if (!isset($_SESSION['logged_in']) || !in_array($_SESSION['role'] ?? '', $allowed_roles, true)) {
    header("Location: ../../../index.php");
    exit();
}

$user_id = $_SESSION['user_id'] ?? null;
$requested_range_id = isset($_GET['range_id']) && is_numeric($_GET['range_id']) ? (int)$_GET['range_id'] : null;
$range_id = $requested_range_id ?: ($_SESSION['range_id'] ?? null);

$range_name = 'Your Range';
$district_name = 'Your District';
$district_id = null;

if (!empty($range_id)) {
    $details_sql = "
        SELECT vr.name AS range_name, d.name AS district_name, d.id AS district_id
        FROM veterinary_ranges vr
        LEFT JOIN districts d ON vr.district_id = d.id
        WHERE vr.id = ?
    ";
    $details_query = $mysqli->prepare($details_sql);
    if ($details_query) {
        $details_query->bind_param("i", $range_id);
        $details_query->execute();
        $details_result = $details_query->get_result();
        if ($data = $details_result->fetch_assoc()) {
            $range_name = $data['range_name'];
            $district_name = $data['district_name'];
            $district_id = $data['district_id'];
        }
        $details_query->close();
    }
}

// Months map & Income Ranges
$months_map = [
    1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April',
    5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August',
    9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
];

$income_ranges = [
    '< Rs. 25,000',
    'Rs. 25,000 - 50,000',
    'Rs. 50,000 - 100,000',
    'Rs. 100,000 - 250,000',
    'Rs. 250,000 - 500,000',
    'Rs. 500,000 - 1,000,000',
    '> Rs. 1,000,000'
];

// Handle GET year & month filters
$selected_year = 'all';
if (isset($_GET['year'])) {
    if ($_GET['year'] === 'all' || $_GET['year'] === '') {
        $selected_year = 'all';
    } else {
        $selected_year = intval($_GET['year']);
    }
}

$selected_month = 'all';
if (isset($_GET['month'])) {
    if ($_GET['month'] === 'all' || $_GET['month'] === '') {
        $selected_month = 'all';
    } else {
        $selected_month = intval($_GET['month']);
    }
}

$range_param = $requested_range_id ? ('&range_id=' . $requested_range_id) : ($range_id ? ('&range_id=' . $range_id) : '');

// Inline CRUD actions:
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'add') {
            $year = intval($_POST['report_year']);
            $month = (!empty($_POST['report_month'])) ? intval($_POST['report_month']) : null;
            $chick_prod_cnt = intval($_POST['chick_producers_count']);
            $chicks_prod_m = intval($_POST['chicks_produced_month']);
            $feed_prod_cnt = intval($_POST['feed_producers_count']);
            $feed_prod_mt = floatval($_POST['feed_production_mt_month']);
            $poultry_proc_cnt = intval($_POST['poultry_processors_count']);
            $chick_sale_live = floatval($_POST['chicken_sale_live_kg_month']);
            $chick_sale_dressed = floatval($_POST['chicken_sale_dressed_kg_month']);
            $org_fert_fam = intval($_POST['organic_fert_farm_families']);
            $org_fert_mt = floatval($_POST['organic_fert_prod_mt_year']);
            $org_fert_sale = floatval($_POST['organic_fert_sale_kg_month']);
            $org_fert_own = floatval($_POST['organic_fert_own_use_kg_month']);
            $org_fert_price = floatval($_POST['organic_fert_price_rs_kg']);
            $income_range = trim($_POST['income_range'] ?? '');

            // Validate duplicate period
            if ($month !== null) {
                $check_stmt = $mysqli->prepare("SELECT id FROM annual_producers_processors WHERE range_id = ? AND report_year = ? AND report_month = ?");
                $check_stmt->bind_param("iii", $range_id, $year, $month);
            } else {
                $check_stmt = $mysqli->prepare("SELECT id FROM annual_producers_processors WHERE range_id = ? AND report_year = ? AND report_month IS NULL");
                $check_stmt->bind_param("ii", $range_id, $year);
            }
            $check_stmt->execute();
            if ($check_stmt->get_result()->num_rows > 0) {
                $period_name = $month ? ($months_map[$month] . " $year") : "Year $year";
                header("Location: annual_producers_processors.php?year=" . urlencode($selected_year) . "&month=" . urlencode($selected_month) . $range_param . "&status=error&msg=" . urlencode("A record for $period_name already exists."));
                exit();
            }
            $check_stmt->close();

            $insert_query = "
                INSERT INTO annual_producers_processors 
                (district_id, range_id, report_year, report_month, chick_producers_count, chicks_produced_month, feed_producers_count, 
                 feed_production_mt_month, poultry_processors_count, chicken_sale_live_kg_month, chicken_sale_dressed_kg_month, 
                 organic_fert_farm_families, organic_fert_prod_mt_year, organic_fert_sale_kg_month, organic_fert_own_use_kg_month, 
                 organic_fert_price_rs_kg, income_range, created_by)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ";
            $stmt = $mysqli->prepare($insert_query);
            if ($stmt) {
                $stmt->bind_param(
                    "iiiiiiididdiddddsi",
                    $district_id,
                    $range_id,
                    $year,
                    $month,
                    $chick_prod_cnt,
                    $chicks_prod_m,
                    $feed_prod_cnt,
                    $feed_prod_mt,
                    $poultry_proc_cnt,
                    $chick_sale_live,
                    $chick_sale_dressed,
                    $org_fert_fam,
                    $org_fert_mt,
                    $org_fert_sale,
                    $org_fert_own,
                    $org_fert_price,
                    $income_range,
                    $user_id
                );
                if ($stmt->execute()) {
                    header("Location: annual_producers_processors.php?year=" . urlencode($selected_year) . "&month=" . urlencode($selected_month) . $range_param . "&status=success&msg=" . urlencode("Data added successfully."));
                } else {
                    header("Location: annual_producers_processors.php?year=" . urlencode($selected_year) . "&month=" . urlencode($selected_month) . $range_param . "&status=error&msg=" . urlencode("Failed to write to database: " . $stmt->error));
                }
                $stmt->close();
            } else {
                header("Location: annual_producers_processors.php?year=" . urlencode($selected_year) . "&month=" . urlencode($selected_month) . $range_param . "&status=error&msg=" . urlencode("Query preparation failed."));
            }
            exit();
        } elseif ($_POST['action'] === 'edit') {
            $id = intval($_POST['id']);
            $year = intval($_POST['report_year']);
            $month = (!empty($_POST['report_month'])) ? intval($_POST['report_month']) : null;
            $chick_prod_cnt = intval($_POST['chick_producers_count']);
            $chicks_prod_m = intval($_POST['chicks_produced_month']);
            $feed_prod_cnt = intval($_POST['feed_producers_count']);
            $feed_prod_mt = floatval($_POST['feed_production_mt_month']);
            $poultry_proc_cnt = intval($_POST['poultry_processors_count']);
            $chick_sale_live = floatval($_POST['chicken_sale_live_kg_month']);
            $chick_sale_dressed = floatval($_POST['chicken_sale_dressed_kg_month']);
            $org_fert_fam = intval($_POST['organic_fert_farm_families']);
            $org_fert_mt = floatval($_POST['organic_fert_prod_mt_year']);
            $org_fert_sale = floatval($_POST['organic_fert_sale_kg_month']);
            $org_fert_own = floatval($_POST['organic_fert_own_use_kg_month']);
            $org_fert_price = floatval($_POST['organic_fert_price_rs_kg']);
            $income_range = trim($_POST['income_range'] ?? '');

            $update_query = "
                UPDATE annual_producers_processors 
                SET report_year = ?, report_month = ?, chick_producers_count = ?, chicks_produced_month = ?, feed_producers_count = ?, 
                    feed_production_mt_month = ?, poultry_processors_count = ?, chicken_sale_live_kg_month = ?, 
                    chicken_sale_dressed_kg_month = ?, organic_fert_farm_families = ?, organic_fert_prod_mt_year = ?, 
                    organic_fert_sale_kg_month = ?, organic_fert_own_use_kg_month = ?, organic_fert_price_rs_kg = ?, 
                    income_range = ?
                WHERE id = ? AND range_id = ?
            ";
            $stmt = $mysqli->prepare($update_query);
            if ($stmt) {
                $stmt->bind_param(
                    "iiiiididdiddddsii",
                    $year,
                    $month,
                    $chick_prod_cnt,
                    $chicks_prod_m,
                    $feed_prod_cnt,
                    $feed_prod_mt,
                    $poultry_proc_cnt,
                    $chick_sale_live,
                    $chick_sale_dressed,
                    $org_fert_fam,
                    $org_fert_mt,
                    $org_fert_sale,
                    $org_fert_own,
                    $org_fert_price,
                    $income_range,
                    $id,
                    $range_id
                );
                if ($stmt->execute()) {
                    header("Location: annual_producers_processors.php?year=" . urlencode($selected_year) . "&month=" . urlencode($selected_month) . $range_param . "&status=success&msg=" . urlencode("Data updated successfully."));
                } else {
                    header("Location: annual_producers_processors.php?year=" . urlencode($selected_year) . "&month=" . urlencode($selected_month) . $range_param . "&status=error&msg=" . urlencode("Failed to update database: " . $stmt->error));
                }
                $stmt->close();
            } else {
                header("Location: annual_producers_processors.php?year=" . urlencode($selected_year) . "&month=" . urlencode($selected_month) . $range_param . "&status=error&msg=" . urlencode("Query preparation failed."));
            }
            exit();
        }
    }
}

if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $mysqli->prepare("DELETE FROM annual_producers_processors WHERE id = ? AND range_id = ?");
    if ($stmt) {
        $stmt->bind_param("ii", $id, $range_id);
        if ($stmt->execute()) {
            header("Location: annual_producers_processors.php?year=" . urlencode($selected_year) . "&month=" . urlencode($selected_month) . $range_param . "&status=success&msg=" . urlencode("Record deleted successfully."));
        } else {
            header("Location: annual_producers_processors.php?year=" . urlencode($selected_year) . "&month=" . urlencode($selected_month) . $range_param . "&status=error&msg=" . urlencode("Failed to delete record."));
        }
        $stmt->close();
    }
    exit();
}

// Fetch records matching year and month filter and range
$records = [];
if (!empty($range_id)) {
    $where_pp = ["range_id = ?"];
    $params_pp = [$range_id];
    $types_pp = "i";

    if ($selected_year !== 'all') {
        $where_pp[] = "report_year = ?";
        $params_pp[] = $selected_year;
        $types_pp .= "i";
    }
    if ($selected_month !== 'all') {
        $where_pp[] = "report_month = ?";
        $params_pp[] = $selected_month;
        $types_pp .= "i";
    }
    $where_pp_sql = implode(" AND ", $where_pp);
    $stmt = $mysqli->prepare("SELECT * FROM annual_producers_processors WHERE $where_pp_sql ORDER BY report_year DESC, report_month DESC, id DESC");
    if ($stmt) {
        $stmt->bind_param($types_pp, ...$params_pp);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) {
            $records[] = $row;
        }
        $stmt->close();
    }
}

// Summary stats
$summary = [
    'chick_producers_sum' => 0,
    'feed_producers_sum' => 0,
    'poultry_processors_sum' => 0,
    'organic_fert_sum' => 0
];
foreach ($records as $r) {
    $summary['chick_producers_sum'] += $r['chick_producers_count'];
    $summary['feed_producers_sum'] += $r['feed_producers_count'];
    $summary['poultry_processors_sum'] += $r['poultry_processors_count'];
    $summary['organic_fert_sum'] += $r['organic_fert_prod_mt_year'];
}

// --- AUTOMATED SUMMARY DASHBOARD AGGREGATIONS (Annual & Monthly Roll-Up) ---
$pp_summary_year = ($selected_year !== 'all') ? intval($selected_year) : intval(date('Y'));

// 1. Yearly Roll-Up Query
$pp_yr_sql = "
    SELECT report_year,
           COUNT(id) as record_count,
           SUM(chick_producers_count) as sum_chick_farms,
           SUM(chicks_produced_month) as sum_chicks_month,
           SUM(feed_producers_count) as sum_feed_farms,
           SUM(feed_production_mt_month) as sum_feed_mt_month,
           SUM(poultry_processors_count) as sum_processors,
           SUM(chicken_sale_live_kg_month) as sum_live_kg,
           SUM(chicken_sale_dressed_kg_month) as sum_dressed_kg,
           SUM(organic_fert_farm_families) as sum_fert_families,
           SUM(organic_fert_prod_mt_year) as sum_fert_mt_year,
           SUM(organic_fert_sale_kg_month) as sum_fert_sale_kg
    FROM annual_producers_processors
    WHERE 1=1 " . (!empty($range_id) ? "AND range_id = ?" : "") . "
    GROUP BY report_year
    ORDER BY report_year DESC
";
$pp_yr_stmt = $mysqli->prepare($pp_yr_sql);
$prod_proc_yearly_rollup = [];
if ($pp_yr_stmt) {
    if (!empty($range_id)) $pp_yr_stmt->bind_param("i", $range_id);
    $pp_yr_stmt->execute();
    $prod_proc_yearly_rollup = $pp_yr_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $pp_yr_stmt->close();
}

// 2. Monthly Progression Query
$pp_mo_sql = "
    SELECT report_month,
           COUNT(id) as record_count,
           SUM(chick_producers_count) as sum_chick_farms,
           SUM(chicks_produced_month) as sum_chicks_month,
           SUM(feed_production_mt_month) as sum_feed_mt_month,
           SUM(chicken_sale_live_kg_month) as sum_live_kg,
           SUM(chicken_sale_dressed_kg_month) as sum_dressed_kg,
           SUM(organic_fert_sale_kg_month) as sum_fert_sale_kg
    FROM annual_producers_processors
    WHERE report_year = ? " . (!empty($range_id) ? "AND range_id = ?" : "") . "
    GROUP BY report_month
    ORDER BY report_month ASC
";
$pp_mo_stmt = $mysqli->prepare($pp_mo_sql);
$prod_proc_monthly_rollup = [];
if ($pp_mo_stmt) {
    if (!empty($range_id)) {
        $pp_mo_stmt->bind_param("ii", $pp_summary_year, $range_id);
    } else {
        $pp_mo_stmt->bind_param("i", $pp_summary_year);
    }
    $pp_mo_stmt->execute();
    $prod_proc_monthly_rollup = $pp_mo_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $pp_mo_stmt->close();
}

require_once '../../../includes/header.php';
?>

<link rel="stylesheet" href="../../../assets/css/bootstrap-icons.min.css">
<link rel="stylesheet" href="../../../assets/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" href="../../../assets/css/buttons.bootstrap5.min.css">
<link rel="stylesheet" href="../../../assets/css/sweetalert2.min.css">
<link rel="stylesheet" href="../../../assets/css/veterinary.css">



        <div class="mb-4 d-flex justify-content-between align-items-center">
            <div>
                <h2 class="h4 fw-bold mb-1" style="color: #370709;">Annual Producers & Processors</h2>
                <p class="text-muted small mb-0">Monitor animal feed, chick production, poultry processing, and organic fertilizer stats for <strong class="text-dark"><?= htmlspecialchars($range_name) ?></strong> (<?= htmlspecialchars($district_name) ?> District)</p>
            </div>

            <div class="d-flex align-items-center gap-2 flex-wrap">
                <form method="GET" class="d-flex align-items-center gap-2 flex-wrap">
                    <?php if ($requested_range_id): ?>
                        <input type="hidden" name="range_id" value="<?= $requested_range_id ?>">
                    <?php endif; ?>
                    <label class="small fw-bold text-muted mb-0">Year:</label>
                    <select name="year" class="form-select form-select-sm" onchange="this.form.submit()" style="width: 105px;">
                        <option value="all" <?= ($selected_year === 'all') ? 'selected' : '' ?>>All Years</option>
                        <?php
                        $curr_year = intval(date('Y'));
                        for ($y = $curr_year - 5; $y <= $curr_year + 5; $y++) {
                            $sel = ($selected_year !== 'all' && $y === intval($selected_year)) ? 'selected' : '';
                            echo "<option value=\"$y\" $sel>$y</option>";
                        }
                        ?>
                    </select>
                    <label class="small fw-bold text-muted mb-0 ms-1">Month:</label>
                    <select name="month" class="form-select form-select-sm" onchange="this.form.submit()" style="width: 120px;">
                        <option value="all" <?= ($selected_month === 'all') ? 'selected' : '' ?>>All Months</option>
                        <?php foreach ($months_map as $m_num => $m_name): ?>
                            <option value="<?= $m_num ?>" <?= ($selected_month !== 'all' && intval($selected_month) === $m_num) ? 'selected' : '' ?>><?= $m_name ?></option>
                        <?php endforeach; ?>
                    </select>
                </form>
                <a href="range_statistics.php<?= $requested_range_id ? '?range_id=' . $requested_range_id : ($range_id ? '?range_id=' . $range_id : '') ?>" class="btn btn-secondary shadow-sm text-nowrap">
                    <i class="bi bi-arrow-left me-2"></i>Back
                </a>
            </div>
        </div>

        <!-- STATS CARD GROUP -->
        <div class="row g-3 mb-4">
            <div class="col-6 col-lg-3">
                <div class="card shadow-sm border-0 border-start border-primary border-4 text-center">
                    <div class="card-body py-3">
                        <span class="text-muted small text-uppercase fw-bold">Active Filter</span>
                        <h4 class="mb-0 fw-bold text-primary mt-1"><?= ($selected_month !== 'all' && isset($months_map[$selected_month]) ? substr($months_map[$selected_month], 0, 3) . ' ' : '') . (($selected_year === 'all') ? 'All Years' : htmlspecialchars($selected_year)) ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-6 col-lg-3">
                <div class="card shadow-sm border-0 border-start border-success border-4 text-center">
                    <div class="card-body py-3">
                        <span class="text-muted small text-uppercase fw-bold">Feed Producers</span>
                        <h4 class="mb-0 fw-bold text-success mt-1"><?= number_format($summary['feed_producers_sum']) ?> Farms</h4>
                    </div>
                </div>
            </div>
            <div class="col-6 col-lg-3">
                <div class="card shadow-sm border-0 border-start border-info border-4 text-center">
                    <div class="card-body py-3">
                        <span class="text-muted small text-uppercase fw-bold">Poultry Processors</span>
                        <h4 class="mb-0 fw-bold text-info mt-1"><?= number_format($summary['poultry_processors_sum']) ?> Nos</h4>
                    </div>
                </div>
            </div>
            <div class="col-6 col-lg-3">
                <div class="card shadow-sm border-0 border-start border-warning border-4 text-center">
                    <div class="card-body py-3">
                        <span class="text-muted small text-uppercase fw-bold">Fertilizer Yield</span>
                        <h4 class="mb-0 fw-bold text-warning mt-1"><?= number_format($summary['organic_fert_sum'], 2) ?> MT</h4>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4 mb-4">
            <div class="col-12">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-white py-3 border-0">
                        <h6 class="mb-0 fw-bold text-dark"><i class="bi bi-grid-3x3-gap-fill me-2"></i>Quick Actions</h6>
                    </div>
                    <div class="card-body pt-0">
                        <div class="row g-3">
                            <div class="col-md-3">
                                <button class="btn btn-primary w-100 py-3 text-light border-0 shadow-sm d-flex flex-column align-items-center justify-content-center" style="background-color: #820100; min-height: 105px;" data-bs-toggle="modal" data-bs-target="#addProdProcModal">
                                    <i class="bi bi-plus-circle fs-3 mb-1"></i>
                                    <span class="small fw-bold text-uppercase">Add Records</span>
                                </button>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Automated Production Outlets Summary (Annual Roll-Up & Summary Calculator) -->
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-header bg-white py-3 border-bottom d-flex justify-content-between align-items-center flex-wrap gap-2">
                <div>
                    <h5 class="card-title mb-0 fw-bold text-dark">
                        <i class="bi bi-calculator-fill text-danger me-2"></i>Automated Production Outlets Summary (Annual Roll-Up)
                    </h5>
                    <small class="text-muted">Real-time compilation of manual entries eliminating manual end-of-year calculations</small>
                </div>
                <div>
                    <ul class="nav nav-pills card-header-pills gap-1" id="ppSummaryTabs" role="tablist">
                        <li class="nav-item">
                            <button class="nav-link active py-1 px-3 fw-bold small btn-sm" id="pp-yearly-tab" data-bs-toggle="pill" data-bs-target="#pp-yearly-content" type="button" role="tab">Yearly Roll-Up</button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link py-1 px-3 fw-bold small btn-sm" id="pp-monthly-tab" data-bs-toggle="pill" data-bs-target="#pp-monthly-content" type="button" role="tab">Monthly Progression (<?= $pp_summary_year ?>)</button>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="tab-content" id="ppSummaryTabContent">
                    <!-- Yearly Roll-Up Tab -->
                    <div class="tab-pane fade show active" id="pp-yearly-content" role="tabpanel">
                        <div class="table-responsive">
                            <table class="table table-hover table-striped align-middle mb-0">
                                <thead class="table-light text-secondary small text-uppercase">
                                    <tr>
                                        <th class="ps-3">Report Year</th>
                                        <th class="text-center">Recorded Entries</th>
                                        <th class="text-end text-primary">Avg Chicks Produced (Nos/mo)</th>
                                        <th class="text-end text-success">Feed Output (MT/mo)</th>
                                        <th class="text-end text-danger">Live Poultry Sold (kg/mo)</th>
                                        <th class="text-end text-danger">Dressed Poultry (kg/mo)</th>
                                        <th class="text-end text-warning pe-3">Organic Fertilizer (MT/yr)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($prod_proc_yearly_rollup)): ?>
                                        <tr>
                                            <td colspan="7" class="text-center py-3 text-muted">No production & processor entries found.</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($prod_proc_yearly_rollup as $row): ?>
                                            <tr>
                                                <td class="ps-3 fw-bold text-dark"><i class="bi bi-calendar-check me-1 text-primary"></i><?= $row['report_year'] ?></td>
                                                <td class="text-center"><span class="badge bg-light text-dark border"><?= number_format($row['record_count']) ?> logs</span></td>
                                                <td class="text-end font-monospace text-primary fw-bold"><?= number_format($row['sum_chicks_month']) ?></td>
                                                <td class="text-end font-monospace text-success fw-bold"><?= number_format($row['sum_feed_mt_month'], 2) ?></td>
                                                <td class="text-end font-monospace text-danger fw-bold"><?= number_format($row['sum_live_kg'], 2) ?></td>
                                                <td class="text-end font-monospace text-danger fw-bold"><?= number_format($row['sum_dressed_kg'], 2) ?></td>
                                                <td class="text-end font-monospace text-warning fw-bold pe-3"><?= number_format($row['sum_fert_mt_year'], 2) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Monthly Breakdown Tab -->
                    <div class="tab-pane fade" id="pp-monthly-content" role="tabpanel">
                        <div class="table-responsive">
                            <table class="table table-hover table-striped align-middle mb-0">
                                <thead class="table-light text-secondary small text-uppercase">
                                    <tr>
                                        <th class="ps-3">Month</th>
                                        <th class="text-center">Recorded Entries</th>
                                        <th class="text-end text-primary">Chicks Produced (Nos)</th>
                                        <th class="text-end text-success">Feed Produced (MT)</th>
                                        <th class="text-end text-danger">Live Poultry Sold (kg)</th>
                                        <th class="text-end text-danger">Dressed Poultry (kg)</th>
                                        <th class="text-end text-warning pe-3">Organic Fert Sales (kg)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($prod_proc_monthly_rollup)): ?>
                                        <tr>
                                            <td colspan="7" class="text-center py-3 text-muted">No monthly logs recorded for <?= $pp_summary_year ?>.</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($prod_proc_monthly_rollup as $m_row): ?>
                                            <tr>
                                                <td class="ps-3 fw-bold text-dark"><i class="bi bi-calendar3 me-1 text-secondary"></i><?= !empty($m_row['report_month']) && isset($months_map[$m_row['report_month']]) ? $months_map[$m_row['report_month']] : 'Annual Aggregate' ?></td>
                                                <td class="text-center"><span class="badge bg-light text-dark border"><?= number_format($m_row['record_count']) ?> logs</span></td>
                                                <td class="text-end font-monospace text-primary fw-bold"><?= number_format($m_row['sum_chicks_month']) ?></td>
                                                <td class="text-end font-monospace text-success fw-bold"><?= number_format($m_row['sum_feed_mt_month'], 2) ?></td>
                                                <td class="text-end font-monospace text-danger fw-bold"><?= number_format($m_row['sum_live_kg'], 2) ?></td>
                                                <td class="text-end font-monospace text-danger fw-bold"><?= number_format($m_row['sum_dressed_kg'], 2) ?></td>
                                                <td class="text-end font-monospace text-warning fw-bold pe-3"><?= number_format($m_row['sum_fert_sale_kg'], 2) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- RECORDS LIST TABLE -->
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center border-bottom">
                <h5 class="card-title mb-0 fw-bold text-dark"><i class="bi bi-table me-2"></i>Logs - <?= ($selected_month !== 'all' && isset($months_map[$selected_month]) ? $months_map[$selected_month] . ' ' : '') . (($selected_year === 'all') ? 'All Years' : htmlspecialchars($selected_year)) ?></h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0" id="prodProcTable" style="min-width: 1800px;">
                        <thead class="table-light text-secondary small uppercase">
                            <tr>
                                <th class="text-center" rowspan="2">Year / Month</th>
                                <th class="text-center text-primary" colspan="2">Chick Production</th>
                                <th class="text-center text-success" colspan="2">Feed Production</th>
                                <th class="text-center text-danger" colspan="3">Poultry Sales (kg/month)</th>
                                <th class="text-center text-warning" colspan="5">Organic Fertilizer Production & Price</th>
                                <th class="text-center text-info" rowspan="2">Income Range</th>
                                <th class="text-center" rowspan="2" style="width: 8%">Actions</th>
                            </tr>
                            <tr>
                                <th class="text-end">Farms</th>
                                <th class="text-end">Chicks/month</th>
                                <th class="text-end">Producers</th>
                                <th class="text-end">MT/month</th>
                                <th class="text-end">Processors</th>
                                <th class="text-end">Live Weight</th>
                                <th class="text-end">Dressed Weight</th>
                                <th class="text-end">Families</th>
                                <th class="text-end">MT/Year</th>
                                <th class="text-end">Sales (kg/mo)</th>
                                <th class="text-end">Own Use (kg)</th>
                                <th class="text-end">Price (Rs/kg)</th>
                            </tr>
                        </thead>
                        <tbody class="small">
                            <?php if (empty($records)): ?>
                                <tr>
                                    <td colspan="15" class="text-center py-4 text-muted">
                                        <i class="bi bi-inbox fs-3 d-block mb-2"></i>
                                        No records located for this period.
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($records as $row): ?>
                                    <tr
                                        data-id="<?= $row['id'] ?>"
                                        data-year="<?= htmlspecialchars($row['report_year']) ?>"
                                        data-month="<?= htmlspecialchars($row['report_month'] ?? '') ?>"
                                        data-income_range="<?= htmlspecialchars($row['income_range'] ?? '') ?>"
                                        data-chick_producers_count="<?= htmlspecialchars($row['chick_producers_count']) ?>"
                                        data-chicks_produced_month="<?= htmlspecialchars($row['chicks_produced_month']) ?>"
                                        data-feed_producers_count="<?= htmlspecialchars($row['feed_producers_count']) ?>"
                                        data-feed_production_mt_month="<?= htmlspecialchars($row['feed_production_mt_month']) ?>"
                                        data-poultry_processors_count="<?= htmlspecialchars($row['poultry_processors_count']) ?>"
                                        data-chicken_sale_live_kg_month="<?= htmlspecialchars($row['chicken_sale_live_kg_month']) ?>"
                                        data-chicken_sale_dressed_kg_month="<?= htmlspecialchars($row['chicken_sale_dressed_kg_month']) ?>"
                                        data-organic_fert_farm_families="<?= htmlspecialchars($row['organic_fert_farm_families']) ?>"
                                        data-organic_fert_prod_mt_year="<?= htmlspecialchars($row['organic_fert_prod_mt_year']) ?>"
                                        data-organic_fert_sale_kg_month="<?= htmlspecialchars($row['organic_fert_sale_kg_month']) ?>"
                                        data-organic_fert_own_use_kg_month="<?= htmlspecialchars($row['organic_fert_own_use_kg_month']) ?>"
                                        data-organic_fert_price_rs_kg="<?= htmlspecialchars($row['organic_fert_price_rs_kg']) ?>">
                                        <td class="text-center fw-bold">
                                            <?= htmlspecialchars($row['report_year']) ?>
                                            <?php if (!empty($row['report_month']) && isset($months_map[$row['report_month']])): ?>
                                                <span class="badge bg-light text-dark border ms-1"><?= substr($months_map[$row['report_month']], 0, 3) ?></span>
                                            <?php else: ?>
                                                <span class="badge bg-light text-muted border ms-1">Annual</span>
                                            <?php endif; ?>
                                        </td>

                                        <td class="text-end font-monospace"><?= number_format($row['chick_producers_count']) ?></td>
                                        <td class="text-end font-monospace"><?= number_format($row['chicks_produced_month']) ?></td>
                                        <td class="text-end font-monospace"><?= number_format($row['feed_producers_count']) ?></td>
                                        <td class="text-end font-monospace bg-light"><?= number_format($row['feed_production_mt_month'], 2) ?></td>

                                        <td class="text-end font-monospace"><?= number_format($row['poultry_processors_count']) ?></td>
                                        <td class="text-end font-monospace"><?= number_format($row['chicken_sale_live_kg_month'], 2) ?></td>
                                        <td class="text-end font-monospace"><?= number_format($row['chicken_sale_dressed_kg_month'], 2) ?></td>

                                        <td class="text-end font-monospace"><?= number_format($row['organic_fert_farm_families']) ?></td>
                                        <td class="text-end font-monospace bg-light"><?= number_format($row['organic_fert_prod_mt_year'], 2) ?></td>
                                        <td class="text-end font-monospace"><?= number_format($row['organic_fert_sale_kg_month'], 2) ?></td>
                                        <td class="text-end font-monospace"><?= number_format($row['organic_fert_own_use_kg_month'], 2) ?></td>
                                        <td class="text-end font-monospace text-success fw-bold">LKR <?= number_format($row['organic_fert_price_rs_kg'], 2) ?></td>

                                        <td class="text-center">
                                            <?php if (!empty($row['income_range'])): ?>
                                                <span class="badge bg-light text-dark border"><?= htmlspecialchars($row['income_range']) ?></span>
                                            <?php else: ?>
                                                <span class="text-muted small">N/A</span>
                                            <?php endif; ?>
                                        </td>

                                        <td class="text-center">
                                            <button class="btn btn-sm btn-outline-primary btn-edit" title="Edit"><i class="bi bi-pencil-square"></i></button>
                                            <a href="annual_producers_processors.php?year=<?= urlencode($selected_year) ?>&month=<?= urlencode($selected_month) ?><?= $range_param ?>&action=delete&id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-danger btn-delete" title="Delete"><i class="bi bi-trash"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </main>
</div>

<!-- Modal: Add Record -->
<div class="modal fade" id="addProdProcModal" tabindex="-1" aria-labelledby="addProdProcModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <form method="POST">
            <input type="hidden" name="action" value="add">
            <?php if ($requested_range_id || $range_id): ?>
                <input type="hidden" name="range_id" value="<?= htmlspecialchars($requested_range_id ?: $range_id) ?>">
            <?php endif; ?>
            <div class="modal-content">
                <div class="modal-header" style="background-color: #370709; color: white;">
                    <h5 class="modal-title" id="addProdProcModalLabel"><i class="bi bi-plus-circle me-2"></i>Add Annual Producers & Processors</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Report Year</label>
                            <input type="number" name="report_year" class="form-control" value="<?= date('Y') ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Report Month</label>
                            <select name="report_month" class="form-select">
                                <option value="">-- Annual (Whole Year) --</option>
                                <?php foreach ($months_map as $m_num => $m_name): ?>
                                    <option value="<?= $m_num ?>" <?= ($selected_month !== 'all' && intval($selected_month) === $m_num) ? 'selected' : '' ?>><?= $m_name ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-md-12">
                            <label class="form-label fw-bold"><i class="bi bi-shield-lock me-1"></i>Monthly Income Range (Private Producers / Processors)</label>
                            <select name="income_range" class="form-select">
                                <option value="">-- Select Income Range (Preserves Privacy) --</option>
                                <?php foreach ($income_ranges as $ir): ?>
                                    <option value="<?= htmlspecialchars($ir) ?>"><?= htmlspecialchars($ir) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="form-text small text-muted">Protects proprietary and personal financial details by recording bracketed ranges instead of exact figures.</div>
                        </div>

                        <div class="col-md-6 border-end">
                            <h6 class="fw-bold text-primary mb-3">Chick Producers</h6>
                            <div class="mb-2">
                                <label class="form-label">No. of Farms</label>
                                <input type="number" name="chick_producers_count" class="form-control" value="0">
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Avg Chicks Produced / month</label>
                                <input type="number" name="chicks_produced_month" class="form-control" value="0">
                            </div>

                            <h6 class="fw-bold text-success mb-3 mt-4">Feed Producers</h6>
                            <div class="mb-2">
                                <label class="form-label">No. of Producers</label>
                                <input type="number" name="feed_producers_count" class="form-control" value="0">
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Monthly Production (MT)</label>
                                <input type="number" step="0.01" name="feed_production_mt_month" class="form-control" value="0.00">
                            </div>

                            <h6 class="fw-bold text-danger mb-3 mt-4">Poultry Processing & Sales</h6>
                            <div class="mb-2">
                                <label class="form-label">No. of Processors</label>
                                <input type="number" name="poultry_processors_count" class="form-control" value="0">
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Sales - Live weight (kg/month)</label>
                                <input type="number" step="0.01" name="chicken_sale_live_kg_month" class="form-control" value="0.00">
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Sales - Dressed weight (kg/month)</label>
                                <input type="number" step="0.01" name="chicken_sale_dressed_kg_month" class="form-control" value="0.00">
                            </div>
                        </div>

                        <div class="col-md-6">
                            <h6 class="fw-bold text-warning mb-3">Organic Fertilizer Production</h6>
                            <div class="mb-2">
                                <label class="form-label">No. of Farm Families</label>
                                <input type="number" name="organic_fert_farm_families" class="form-control" value="0">
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Total Production (MT/Year)</label>
                                <input type="number" step="0.01" name="organic_fert_prod_mt_year" class="form-control" value="0.00">
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Avg Sales (kg/month)</label>
                                <input type="number" step="0.01" name="organic_fert_sale_kg_month" class="form-control" value="0.00">
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Avg Own Use (kg/month)</label>
                                <input type="number" step="0.01" name="organic_fert_own_use_kg_month" class="form-control" value="0.00">
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Avg Selling Price (Rs./kg)</label>
                                <input type="number" step="0.01" name="organic_fert_price_rs_kg" class="form-control" value="0.00">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success">Save Record</button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Modal: Edit Record -->
<div class="modal fade" id="editProdProcModal" tabindex="-1" aria-labelledby="editProdProcModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <form method="POST">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" id="edit_id">
            <?php if ($requested_range_id || $range_id): ?>
                <input type="hidden" name="range_id" value="<?= htmlspecialchars($requested_range_id ?: $range_id) ?>">
            <?php endif; ?>
            <div class="modal-content">
                <div class="modal-header" style="background-color: #370709; color: white;">
                    <h5 class="modal-title" id="editProdProcModalLabel"><i class="bi bi-pencil-square me-2"></i>Edit Annual Producers & Processors</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Report Year</label>
                            <input type="number" name="report_year" id="edit_report_year" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Report Month</label>
                            <select name="report_month" id="edit_report_month" class="form-select">
                                <option value="">-- Annual (Whole Year) --</option>
                                <?php foreach ($months_map as $m_num => $m_name): ?>
                                    <option value="<?= $m_num ?>"><?= $m_name ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-md-12">
                            <label class="form-label fw-bold"><i class="bi bi-shield-lock me-1"></i>Monthly Income Range (Private Producers / Processors)</label>
                            <select name="income_range" id="edit_income_range" class="form-select">
                                <option value="">-- Select Income Range (Preserves Privacy) --</option>
                                <?php foreach ($income_ranges as $ir): ?>
                                    <option value="<?= htmlspecialchars($ir) ?>"><?= htmlspecialchars($ir) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="form-text small text-muted">Protects proprietary and personal financial details by recording bracketed ranges instead of exact figures.</div>
                        </div>

                        <div class="col-md-6 border-end">
                            <h6 class="fw-bold text-primary mb-3">Chick Producers</h6>
                            <div class="mb-2">
                                <label class="form-label">No. of Farms</label>
                                <input type="number" name="chick_producers_count" id="edit_chick_producers_count" class="form-control">
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Avg Chicks Produced / month</label>
                                <input type="number" name="chicks_produced_month" id="edit_chicks_produced_month" class="form-control">
                            </div>

                            <h6 class="fw-bold text-success mb-3 mt-4">Feed Producers</h6>
                            <div class="mb-2">
                                <label class="form-label">No. of Producers</label>
                                <input type="number" name="feed_producers_count" id="edit_feed_producers_count" class="form-control">
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Monthly Production (MT)</label>
                                <input type="number" step="0.01" name="feed_production_mt_month" id="edit_feed_production_mt_month" class="form-control">
                            </div>

                            <h6 class="fw-bold text-danger mb-3 mt-4">Poultry Processing & Sales</h6>
                            <div class="mb-2">
                                <label class="form-label">No. of Processors</label>
                                <input type="number" name="poultry_processors_count" id="edit_poultry_processors_count" class="form-control">
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Sales - Live weight (kg/month)</label>
                                <input type="number" step="0.01" name="chicken_sale_live_kg_month" id="edit_chicken_sale_live_kg_month" class="form-control">
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Sales - Dressed weight (kg/month)</label>
                                <input type="number" step="0.01" name="chicken_sale_dressed_kg_month" id="edit_chicken_sale_dressed_kg_month" class="form-control">
                            </div>
                        </div>

                        <div class="col-md-6">
                            <h6 class="fw-bold text-warning mb-3">Organic Fertilizer Production</h6>
                            <div class="mb-2">
                                <label class="form-label">No. of Farm Families</label>
                                <input type="number" name="organic_fert_farm_families" id="edit_organic_fert_farm_families" class="form-control">
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Total Production (MT/Year)</label>
                                <input type="number" step="0.01" name="organic_fert_prod_mt_year" id="edit_organic_fert_prod_mt_year" class="form-control">
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Avg Sales (kg/month)</label>
                                <input type="number" step="0.01" name="organic_fert_sale_kg_month" id="edit_organic_fert_sale_kg_month" class="form-control">
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Avg Own Use (kg/month)</label>
                                <input type="number" step="0.01" name="organic_fert_own_use_kg_month" id="edit_organic_fert_own_use_kg_month" class="form-control">
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Avg Selling Price (Rs./kg)</label>
                                <input type="number" step="0.01" name="organic_fert_price_rs_kg" id="edit_organic_fert_price_rs_kg" class="form-control">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update Record</button>
                </div>
            </div>
        </form>
    </div>
</div>

<?php
$pageScripts = '
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
$(document).ready(function() {
    $("#prodProcTable").DataTable({
        "orderCellsTop": true,
        "autoWidth": false,
        "order": [[0, "desc"]],
        "pageLength": 10,
        "dom": "Bfrtip",
        "buttons": [
            {
                extend: "csv",
                text: "<i class=\\"bi bi-file-earmark-spreadsheet\\"></i> CSV",
                className: "btn btn-sm btn-success me-2"
            },
            {
                extend: "pdf",
                text: "<i class=\\"bi bi-file-pdf\\"></i> PDF",
                className: "btn btn-sm btn-danger me-2"
            },
            {
                extend: "print",
                text: "<i class=\\"bi bi-printer\\"></i> Print",
                className: "btn btn-sm btn-dark"
            }
        ]
    });

    var urlParams = new URLSearchParams(window.location.search);
    var status = urlParams.get(\'status\');
    var msg = urlParams.get(\'msg\') || \'\';

    if (status === \'success\') {
        Swal.fire({
            icon: \'success\',
            title: \'Success!\',
            text: msg ? msg : \'Operation completed successfully.\',
            confirmButtonColor: \'#370709\'
        });
        window.history.replaceState({}, document.title, window.location.pathname);
    } else if (status === \'error\') {
        Swal.fire({
            icon: \'error\',
            title: \'Operation Failed\',
            text: msg ? msg : \'Could not process database action.\',
            confirmButtonColor: \'#370709\'
        });
        window.history.replaceState({}, document.title, window.location.pathname);
    }

    $(document).on(\'click\', \'.btn-edit\', function() {
        var $row = $(this).closest(\'tr\');
        $(\'#edit_id\').val($row.data(\'id\'));
        $(\'#edit_report_year\').val($row.data(\'year\'));
        $(\'#edit_report_month\').val($row.data(\'month\') || \'\');
        $(\'#edit_income_range\').val($row.data(\'income_range\') || \'\');
        $(\'#edit_chick_producers_count\').val($row.data(\'chick_producers_count\'));
        $(\'#edit_chicks_produced_month\').val($row.data(\'chicks_produced_month\'));
        $(\'#edit_feed_producers_count\').val($row.data(\'feed_producers_count\'));
        $(\'#edit_feed_production_mt_month\').val($row.data(\'feed_production_mt_month\'));
        $(\'#edit_poultry_processors_count\').val($row.data(\'poultry_processors_count\'));
        $(\'#edit_chicken_sale_live_kg_month\').val($row.data(\'chicken_sale_live_kg_month\'));
        $(\'#edit_chicken_sale_dressed_kg_month\').val($row.data(\'chicken_sale_dressed_kg_month\'));
        $(\'#edit_organic_fert_farm_families\').val($row.data(\'organic_fert_farm_families\'));
        $(\'#edit_organic_fert_prod_mt_year\').val($row.data(\'organic_fert_prod_mt_year\'));
        $(\'#edit_organic_fert_sale_kg_month\').val($row.data(\'organic_fert_sale_kg_month\'));
        $(\'#edit_organic_fert_own_use_kg_month\').val($row.data(\'organic_fert_own_use_kg_month\'));
        $(\'#edit_organic_fert_price_rs_kg\').val($row.data(\'organic_fert_price_rs_kg\'));

        new bootstrap.Modal(document.getElementById(\'editProdProcModal\')).show();
    });

    $(document).on(\'click\', \'.btn-delete\', function(e) {
        e.preventDefault();
        var deleteUrl = $(this).attr(\'href\');
        var $row = $(this).closest(\'tr\');
        var year = $row.data(\'year\');

        Swal.fire({
            icon: \'warning\',
            title: \'Delete Record?\',
            html: \'Are you sure you want to permanently delete this record for year <strong>\' + year + \'</strong>?<br>This action cannot be undone.\',
            showCancelButton: true,
            confirmButtonColor: \'#d33\',
            cancelButtonColor: \'#6c757d\',
            confirmButtonText: \'Yes, Delete\',
            cancelButtonText: \'Cancel\'
        }).then(function(result) {
            if (result.isConfirmed) {
                window.location.href = deleteUrl;
            }
        });
    });
});
</script>
';
require_once '../../../includes/footer.php';
?>