<!-- Issue Individual Certificate / Counterfoil Leaf Modal -->
<div class="modal fade" id="issueCounterfoilLeafModal" tabindex="-1" aria-labelledby="issueCounterfoilLeafModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content rounded-4 border-0 shadow-lg overflow-hidden">
            <!-- Modal Header -->
            <div class="modal-header text-white border-0 py-3 px-4" style="background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);">
                <div class="d-flex align-items-center gap-3">
                    <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background: rgba(255,255,255,0.15); width: 44px; height: 44px;">
                        <i class="bi bi-file-earmark-person fs-4 text-white"></i>
                    </div>
                    <div>
                        <h5 class="modal-title fw-bold mb-0" id="issueCounterfoilLeafModalLabel">Issue Individual Certificate / Leaf</h5>
                        <small class="text-white-50" style="font-size: 12px;">Issue audited certificate/leaf from counterfoil book directly to farmer</small>
                    </div>
                </div>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <form id="formIssueCounterfoilLeaf" action="processors/save_counterfoil_leaf_issue.php" method="POST">
                <input type="hidden" name="district_id" value="<?= htmlspecialchars($district_id ?? '') ?>">
                <input type="hidden" name="range_id" value="<?= htmlspecialchars($range_id ?? '') ?>">
                <input type="hidden" name="animal_counts_summary" id="leaf_animal_counts_summary" value="">

                <div class="modal-body p-4 bg-light-subtle">
                    <!-- SECTION 1: Book & Leaf Reference -->
                    <div class="card border-0 shadow-sm rounded-3 mb-3">
                        <div class="card-body p-3">
                            <h6 class="text-uppercase fw-bold text-muted small mb-3" style="letter-spacing: 0.5px;">
                                <i class="bi bi-book me-1 text-primary"></i> Parent Counterfoil Book &amp; Leaf Serial
                            </h6>
                            <div class="row g-3">
                                <div class="col-md-7">
                                    <label class="form-label small fw-bold text-dark">
                                        Source Counterfoil Book <span class="text-danger">*</span>
                                    </label>
                                    <select name="counterfoil_id" id="leaf_counterfoil_id" class="form-select" required>
                                        <option value="" disabled selected>-- Select Authorized Farmer Book --</option>
                                        <?php
                                        if (!function_exists('isFarmerRelatedBook')) {
                                            function isFarmerRelatedBook($type) {
                                                $clean = strtolower(preg_replace('/[^a-z0-9]/i', '', $type));
                                                $valid_keys = [
                                                    'airegister',
                                                    'animaltransport',
                                                    'aicertificatebook',
                                                    'aicertificate',
                                                    'cashreceiptbook',
                                                    'cashreceipt',
                                                    'certificateforslaughterofbuffalo',
                                                    'healthcertificate',
                                                    'ownershipvoucher',
                                                    'registerofcattlebranded',
                                                    'cattlebranded',
                                                    'registerforanimalidentificationschedule08',
                                                    'registerforanimalidentification',
                                                    'schedule08',
                                                    'pivschedule08',
                                                    'arvregister',
                                                    'animalbirthcontrolregister',
                                                    'produceregister'
                                                ];
                                                foreach ($valid_keys as $vk) {
                                                    if ($clean === $vk || strpos($clean, $vk) !== false || strpos($vk, $clean) !== false) {
                                                        return true;
                                                    }
                                                }
                                                return false;
                                            }
                                        }

                                        $matching_books = [];
                                        if (!empty($range_id)) {
                                            $b_stmt = $mysqli->prepare("SELECT id, counterfoil_type, book_serial_no, page_count, available_quantity FROM counterfoil_assets WHERE range_id = ? AND is_active = 1 ORDER BY counterfoil_type ASC, id DESC");
                                            if ($b_stmt) {
                                                $b_stmt->bind_param("i", $range_id);
                                                $b_stmt->execute();
                                                $b_res = $b_stmt->get_result();
                                                while ($bk = $b_res->fetch_assoc()) {
                                                    if (isFarmerRelatedBook($bk['counterfoil_type'])) {
                                                        $matching_books[] = $bk;
                                                    }
                                                }
                                                $b_stmt->close();
                                            }
                                        }

                                        if (!empty($matching_books)) {
                                            echo '<optgroup label="Authorized Farmer Counterfoil Books in Custody">';
                                            foreach ($matching_books as $bk) {
                                                $label = htmlspecialchars($bk['counterfoil_type']);
                                                if (!empty($bk['book_serial_no'])) $label .= " (Serial: " . htmlspecialchars($bk['book_serial_no']) . ")";
                                                if (!empty($bk['page_count'])) $label .= " - " . htmlspecialchars($bk['page_count']) . " Leaves";
                                                $label .= " [Available: " . intval($bk['available_quantity']) . "]";
                                                echo "<option value=\"{$bk['id']}\" data-type=\"" . htmlspecialchars($bk['counterfoil_type']) . "\">{$label}</option>";
                                            }
                                            echo '</optgroup>';
                                        } else {
                                            echo '<option value="" disabled>No farmer-related counterfoil books currently registered in custody</option>';
                                        }
                                        ?>
                                    </select>
                                    <div class="mt-1 d-flex align-items-center gap-1">
                                        <span class="badge bg-success-subtle text-success border border-success-subtle py-1 px-2" style="font-size: 11px;">
                                            <i class="bi bi-shield-check me-1"></i>Restricted View: Limited to 12 Authorized Farmer Book Types
                                        </span>
                                    </div>
                                    <small class="text-muted d-block mt-1" style="font-size: 11px;">
                                        Only displays AI Register, Animal Transport, AI cert, Cash receipt, Slaughter cert, Health cert, Ownership voucher, Cattle branded, Animal ID (Schedule 08), ARV, Animal birth control, &amp; Produce register.
                                    </small>
                                </div>
                                <div class="col-md-5">
                                    <label class="form-label small fw-bold text-dark">
                                        Specific Leaf / Serial Number <span class="text-danger">*</span>
                                    </label>
                                    <input type="text" name="leaf_serial_no" id="leaf_serial_no" class="form-control font-monospace fw-bold" placeholder="e.g. 001024 or HC/2026/045" required>
                                    <small class="text-muted" style="font-size: 11px;">Unique leaf number issued from the book</small>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- SECTION 2: Farmer NIC & Auto-Pull Details -->
                    <div class="card border-0 shadow-sm rounded-3 mb-3 border-start border-primary border-4">
                        <div class="card-body p-3">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <h6 class="text-uppercase fw-bold text-primary small mb-0" style="letter-spacing: 0.5px;">
                                    <i class="bi bi-person-badge-fill me-1"></i> Farmer Identity &amp; Auto-Pull
                                </h6>
                                <span id="leaf_nic_status_badge" class="badge bg-secondary-subtle text-secondary small" style="display: none;"></span>
                            </div>

                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold text-dark">
                                        Farmer Identity Card Number (NIC) <span class="text-danger">*</span>
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-white border-end-0 text-muted"><i class="bi bi-card-heading"></i></span>
                                        <input type="text" 
                                               name="farmer_nic" 
                                               id="leaf_farmer_nic" 
                                               class="form-control border-start-0 font-monospace fw-bold" 
                                               placeholder="e.g. 198214502391 or 765421980V" 
                                               autocomplete="off" 
                                               required>
                                        <button class="btn btn-outline-secondary" type="button" id="btn_lookup_leaf_nic" onclick="lookupLeafFarmerNIC()" title="Query Farmer Database">
                                            <i class="bi bi-search"></i>
                                        </button>
                                    </div>
                                    <small class="text-muted" style="font-size: 11px;">
                                        Type NIC to instantly pull Farm Reg No., Address, and Live Animal Counts.
                                    </small>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label small fw-bold text-dark">Farm Registration No.</label>
                                    <input type="text" name="farm_registration_no" id="leaf_farm_registration_no" class="form-control font-monospace" placeholder="Auto-filled or enter FRN">
                                    <small class="text-muted" style="font-size: 11px;">Departmental Farm Registration ID</small>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label small fw-bold text-dark">Farmer Full Name <span class="text-danger">*</span></label>
                                    <input type="text" name="farmer_name" id="leaf_farmer_name" class="form-control" placeholder="Auto-filled farmer name" required>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label small fw-bold text-dark">Issue Date <span class="text-danger">*</span></label>
                                    <input type="date" name="issue_date" id="leaf_issue_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                                </div>

                                <div class="col-12">
                                    <label class="form-label small fw-bold text-dark">Location / Farm Address</label>
                                    <textarea name="location_address" id="leaf_location_address" class="form-control" rows="2" placeholder="Auto-filled farm address or enter location"></textarea>
                                </div>

                                <!-- Dynamic Animal Counts Panel -->
                                <div class="col-12" id="leaf_animal_counts_container" style="display: none;">
                                    <div class="p-3 bg-light rounded-3 border">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <label class="form-label small fw-bold text-dark mb-0">
                                                <i class="bi bi-pie-chart-fill text-success me-1"></i>Registered Animal Population Breakdown
                                            </label>
                                            <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-1 small">
                                                <i class="bi bi-database-check me-1"></i>Verified Master Registry
                                            </span>
                                        </div>
                                        <div class="d-flex flex-wrap gap-2" id="leaf_animal_badges">
                                            <!-- Dynamically injected -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- SECTION 3: Physical Yellow Receipt Leaf Details & Cashbook Revenue Mapping -->
                    <div class="card border-0 shadow-sm rounded-3 mb-3 border-start border-warning border-4" style="background-color: #fffdf5;">
                        <div class="card-body p-3">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <div>
                                    <h6 class="text-uppercase fw-bold text-dark small mb-0" style="letter-spacing: 0.5px;">
                                        <i class="bi bi-receipt-cutoff me-1 text-warning"></i> Physical Yellow Receipt Details (GF 172)
                                    </h6>
                                    <small class="text-muted" style="font-size: 11px;">Captures client revenue and feeds directly into Cashbook Summary</small>
                                </div>
                                <span id="leaf_category_preview_badge" class="badge bg-warning text-dark border border-warning px-2.5 py-1.5 fw-bold" style="font-size: 11px;">
                                    <i class="bi bi-lightning-charge-fill me-1"></i>Maps to: <span id="leaf_mapped_cat_text">Tab 1: Consultations</span>
                                </span>
                            </div>

                            <div class="row g-3">
                                <!-- Activity Item / Purpose Preset Selector -->
                                <div class="col-md-7">
                                    <label class="form-label small fw-bold text-dark">
                                        Purpose / Revenue Activity Item <span class="text-danger">*</span>
                                    </label>
                                    <select id="leaf_purpose_selector" class="form-select form-select-sm" style="border-radius: 6px;">
                                        <optgroup label="Tab 1: Consultations & Certificates">
                                            <option value="Consultation fee for pure breed dog" data-price="150.00" data-tab="tab-consultations" selected>Consultation fee for pure breed dog (Rs. 150.00)</option>
                                            <option value="Consultation fee for cross breed Pet's" data-price="100.00" data-tab="tab-consultations">Consultation fee for cross breed Pet's (Rs. 100.00)</option>
                                            <option value="Health certificate" data-price="250.00" data-tab="tab-consultations">Health certificate (Rs. 250.00)</option>
                                        </optgroup>
                                        <optgroup label="Tab 2: Poultry Sales & Semen">
                                            <option value="Day old unsexed backyard chicks" data-price="120.00" data-tab="tab-poultry">Day old unsexed backyard chicks</option>
                                            <option value="Semen straws for AI services" data-price="200.00" data-tab="tab-poultry">Semen straws for AI services</option>
                                            <option value="Day Old Cockerels" data-price="80.00" data-tab="tab-poultry">Day Old Cockerels</option>
                                        </optgroup>
                                        <optgroup label="Tab 3: Vaccines, Surgeries & Treatments">
                                            <option value="Wound ress (Wound dress)" data-price="150.00" data-tab="tab-treatments">Wound ress (Wound dress)</option>
                                            <option value="Ranikhet 1st dose & 2nd Dose" data-price="50.00" data-tab="tab-treatments">Ranikhet 1st dose & 2nd Dose</option>
                                            <option value="OHE - Dog" data-price="1500.00" data-tab="tab-treatments">OHE - Dog (Rs. 1,500.00)</option>
                                            <option value="OHE -Cat" data-price="1000.00" data-tab="tab-treatments">OHE -Cat (Rs. 1,000.00)</option>
                                        </optgroup>
                                        <optgroup label="Tab 4: Post Mortems">
                                            <option value="Poultry -Bird post mortems" data-price="100.00" data-tab="tab-post-mortems">Poultry -Bird post mortems</option>
                                            <option value="Post moturm Rabbit" data-price="150.00" data-tab="tab-post-mortems">Post moturm Rabbit</option>
                                        </optgroup>
                                        <option value="__custom__">-- Other / Enter Custom Revenue Description --</option>
                                    </select>
                                    
                                    <!-- Actual Purpose Input (Hidden if using preset, shown if custom) -->
                                    <input type="text" name="purpose" id="leaf_purpose" class="form-control form-control-sm mt-2 font-monospace fw-bold" value="Consultation fee for pure breed dog" placeholder="Describe specific revenue activity..." required>
                                    <input type="hidden" name="revenue_item" id="leaf_revenue_item" value="Consultation fee for pure breed dog">
                                    <input type="hidden" name="category_tab" id="leaf_category_tab" value="tab-consultations">
                                </div>

                                <!-- Quantity Sold -->
                                <div class="col-md-2 col-sm-6">
                                    <label class="form-label small fw-bold text-dark">Quantity <span class="text-danger">*</span></label>
                                    <input type="number" name="quantity" id="leaf_quantity" class="form-control form-control-sm text-end font-monospace fw-bold" value="1" min="1" step="1" required>
                                </div>

                                <!-- Unit Price (Rs.) -->
                                <div class="col-md-3 col-sm-6">
                                    <label class="form-label small fw-bold text-dark">Unit Price (Rs.)</label>
                                    <input type="number" name="unit_price" id="leaf_unit_price" class="form-control form-control-sm text-end font-monospace" value="150.00" min="0" step="0.01">
                                </div>

                                <!-- Total Amount (Rs. / Cts.) -->
                                <div class="col-md-4 col-sm-6">
                                    <label class="form-label small fw-bold text-dark">
                                        Total Amount (Rs.) <span class="text-danger">*</span>
                                    </label>
                                    <div class="input-group input-group-sm">
                                        <span class="input-group-text bg-white fw-bold">Rs.</span>
                                        <input type="number" name="amount" id="leaf_amount" class="form-control text-end font-monospace fw-bold fs-6 text-dark" value="150.00" min="0" step="0.01" required>
                                    </div>
                                    <small class="text-muted" style="font-size: 10px;">Quantity &times; Unit Price</small>
                                </div>

                                <!-- Amount Deposited in Bank -->
                                <div class="col-md-4 col-sm-6">
                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                        <label class="form-label small fw-bold text-dark mb-0">Bank Deposited (Rs.)</label>
                                        <button type="button" class="btn btn-link btn-xs p-0 text-success text-decoration-none fw-bold" id="btn_leaf_deposit_full" style="font-size: 11px;">
                                            Deposit in Full
                                        </button>
                                    </div>
                                    <div class="input-group input-group-sm">
                                        <span class="input-group-text bg-white fw-bold text-success">Rs.</span>
                                        <input type="number" name="amount_deposited" id="leaf_amount_deposited" class="form-control text-end font-monospace fw-bold fs-6 text-success" value="150.00" min="0" step="0.01">
                                    </div>
                                    <small class="text-muted" style="font-size: 10px;">Amount remitted to government account</small>
                                </div>

                                <!-- Additional Remarks -->
                                <div class="col-md-4 col-sm-12">
                                    <label class="form-label small fw-bold text-dark">Officer Notes / Remarks</label>
                                    <input type="text" name="remarks" class="form-control form-control-sm" placeholder="e.g. Paid in cash, receipt issued">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modal Footer -->
                <div class="modal-footer bg-white border-top py-3 px-4 d-flex justify-content-between align-items-center">
                    <div class="small text-muted d-flex align-items-center gap-1">
                        <i class="bi bi-check-circle-fill text-success"></i>
                        <span>Automated Feed: Logs receipt leaf &amp; immediately refreshes Cashbook Summary.</span>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="button" class="btn btn-outline-secondary px-3 fw-semibold rounded-pill" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" id="btn_submit_issue_leaf" class="btn text-white px-4 fw-semibold rounded-pill shadow-sm" style="background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);">
                            <i class="bi bi-receipt me-1"></i> Issue Receipt Leaf
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

